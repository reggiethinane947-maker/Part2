/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchat;

/**
 *
 * @author Shimi
 */

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Quickchat {
    private String messageID;
    private int messagenumber;
    private String recipient;
    private String message;
    private String messageHash;
    
    private static int totalMessageSent = 0;
    private static String sentMessages = 0;

    public Message(int messageNumber,String recipient, String message){
    this.messagenumber = messagenumber;
    this.recipient = recipient;
    this.message = message;
    this.messageID = messageID;
    this.messageHash = messageHash;  
    }
    
    public String generateMessageID(){
        Random random = new Random();
        String id = "";
        
        for(int i = 0; i < 10; i++){
            int digit = random.nextInt(10);
            id += digit;
        }
        return id;
    }
  
    public boolean checkMessageID(){
     return messageID.length() <=10;
    }
    
   public String checkRecipientCell(){
       String cellRegex = "^\\+27\\d(9)$";
       
       if(recipient.matches(cellRegex)){
           return "Cellphone number is successfully captured";
       }else {
           return "Cellphone number is incorrectly formated or it dosent contain an international code: +27";
       }  
   }
   
   public boolean isRecipientValid(){
       return recipient.matches("^\\+27\\d(9)$");
   }
   
   public String checkMessageLength(){
       if(message.length()<=250){
           return "Message is ready to send";
       }
       else{
       int extraCharacters = message.length() - 250;
       return "Message exceeds 250 Characters by "+ extraCharacters;
       }
   }
    public boolean isMessageValid(){
        return message.length()<=250;
    }
    
    public String createMessageHash(){
        String[] words = message.trim().split("\\\\s+");
        
        String firstWord = words[0];
        String lastWord = words[words.length-1];
        firstWord = firstWord.replaceAll("[^a-zA-zo-9]", "");
        lastWord = lastWord.replaceAll("[a-zA-zo-9]", "");
        
        String hash = messageID.substring(0,2)
                +":"
                +messageNumber
                +":"
                +firstWord
                +lastWord;
        return hash.UpperCase();
    }
    
    public String sentMessage(int option){
        if(option ==1){
            totalMessageSent++;
            
            sentMessages += printMessageDetails()
                    +System.lineSeparator()
                    +"====================="
                    + System.lineSeparator();
            
            return "Message is successfuly sent.";
        }else if (option ==0){
            return "Press 0 to delete this message.";
        }else if (option ==2){
            return "Message successfuly stored.";
        }else {
            return "invalid option";
        }
    }
    
    public String pritMessages(){
        if(sentMessages.inEmpty()){
            return "No messages sent";
        }
        return sentMassages;
    }
    public int returnTotalMessages(){
        return totalMessagesSent;
    }
    
    public String printMessagesDetails(){
        return "MessageID: "+messageID
                +System.lineSeparator()
                +"Message hash: "+ messageHash
                +"Recipient: "+ recipient
                +"Message: "+ message;
    }
    
    public String storeMessage(){
    
    }
    
}
