/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Shimi
 */

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

public class AppTest {
    
    private Message message;
    
    @BeforeEach
    public void setUp() {
        message = new Message();
    }
    
    @Test
    public void testCheckMessageID() {
        // Test that message ID is generated and valid (not more than 10 chars)
        assertTrue(message.checkMessageID(), "Message ID should be 10 characters or less");
        
        // Test that message ID is exactly 10 characters
        assertEquals(10, message.getMessageID().length(), "Message ID should be exactly 10 digits");
    }
    
    @Test
    public void testCheckRecipientCellSuccess() {
        // Test successful cell number capture
        String result = message.checkRecipientCell("+27718693002");
        assertEquals("Cell phone number successfully captured.", result);
    }
    
    @Test
    public void testCheckRecipientCellFailureNoPlus() {
        // Test failure - no international code
        String result = message.checkRecipientCell("27718693002");
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", result);
    }
    
    @Test
    public void testCheckRecipientCellFailureTooLong() {
        // Test failure - too long
        String result = message.checkRecipientCell("+27718693002123");
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", result);
    }
    
    @Test
    public void testValidateMessageLengthSuccess() {
        // Test successful message validation
        String result = message.validateMessageLength("Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message ready to send.", result);
    }
    
    @Test
    public void testValidateMessageLengthFailure() {
        // Test failure - message too long
        String longMessage = "a".repeat(260);
        String result = message.validateMessageLength(longMessage);
        assertTrue(result.contains("Message exceeds 250 characters by"));
        assertTrue(result.contains("please reduce the size."));
    }
    
    @Test
    public void testCreateMessageHash() {
        // Setup
        message.checkRecipientCell("+27718693002");
        message.validateMessageLength("Hi Mike, can you join us for dinner tonight?");
        
        // Test hash creation with message "Hi Mike, can you join us for dinner tonight?"
        // First word: "Hi", Last word: "tonight?"
        String hash = message.createMessageHash();
        
        // Hash format: first 2 chars of ID : 0 : HITONIGHT?
        assertNotNull(hash);
        assertTrue(hash.contains(":"));
        String[] parts = hash.split(":");
        assertEquals(3, parts.length);
        assertEquals(2, parts[0].length()); // First 2 chars of ID
        assertEquals("0", parts[1]); // Initial count is 0
        // Parts[2] should be uppercase first and last words
        assertTrue(parts[2].equals(parts[2].toUpperCase())); // All caps
    }
    
    @Test
    public void testSentMessageSend() {
        message.checkRecipientCell("+27718693002");
        message.validateMessageLength("Hi Mike, can you join us for dinner tonight?");
        message.createMessageHash();
        
        String result = message.SentMessage(1); // Send
        assertEquals("Message successfully sent.", result);
    }
    
    @Test
    public void testSentMessageDisregard() {
        message.checkRecipientCell("+27718693002");
        message.validateMessageLength("Hi Mike, can you join us for dinner tonight?");
        
        String result = message.SentMessage(2); // Disregard
        assertEquals("Press 0 to delete the message.", result);
    }
    
    @Test
    public void testSentMessageStore() {
        message.checkRecipientCell("+27718693002");
        message.validateMessageLength("Hi Mike, can you join us for dinner tonight?");
        
        String result = message.SentMessage(3); // Store
        assertEquals("Message successfully stored.", result);
    }
    
    @Test
    public void testReturnTotalMessages() {
        // Reset by creating new test
    
}
}
